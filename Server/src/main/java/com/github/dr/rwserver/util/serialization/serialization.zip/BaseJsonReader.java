package com.github.dr.rwserver.util.serialization;

import com.github.dr.rwserver.util.file.FileUtil;

import java.io.IOException;
import java.io.InputStream;

public interface BaseJsonReader{
    JsonValue parse(InputStream input);

    default JsonValue parse(FileUtil fileUtil){
        try {
            return parse(fileUtil.getInputsStream());
        } catch (IOException e) {
        }
        return null;
    }
}
